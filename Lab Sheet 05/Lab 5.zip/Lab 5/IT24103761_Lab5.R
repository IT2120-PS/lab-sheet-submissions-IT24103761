getwd()
setwd("C:\\Users\\Viraj\\OneDrive\\Desktop\\Lab 5")
getwd()
data<-read.table("Data.txt",header=TRUE,sep=",")
fix(data)
attach(data)

names(data)<-c("X1","X2")
attach(data)
hist(X2,main="Histogram for number of shareholders")

histogram<-hist(X2,main="histogram for number of shareholders"breaks=seq(130,270,length=8),right=FALSE)
?hist

breaks<-round(histogram$breaks)
freq<-histogram$counts
mids<- c()
classes<-c()
for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i]," , ",breaks[i+1],"]")
}
cbint(Classes = classes,Frequency=freq)

lines(mids,freq)
plot(mids,freq,type='1',main="frequency Polygon for shareholders",xlab="shareholders",ylab="Frequency"ylim=c(0,max(freq)))

cum.freq<-cumsum(freq)
new<-c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }
  else {
    new[i]=cum.freq[i-1]
  }
}
plot(breaks,new,type='l'main="cumalative frequency polygon for shareholders",
  xlab="Shareholders",ylab="Cumulative frequency",ylim=c(0,max(cum.freq)))
cbid(Upper = breaks ,CumFreq=new)
